package com.nagarro.nagp.urbanclap.servicesmanagement.Domain;

import java.util.List;

public class ServiceProviderReviews {

    private String serviceProviderType;

    private List<ServiceProviderInfo> serviceProviderInfoList;



}
