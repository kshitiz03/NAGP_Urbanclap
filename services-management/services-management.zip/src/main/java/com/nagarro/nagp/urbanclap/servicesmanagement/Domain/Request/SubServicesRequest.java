package com.nagarro.nagp.urbanclap.servicesmanagement.Domain.Request;

public class SubServicesRequest {

    private String service;

    private String subService;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getSubService() {
        return subService;
    }

    public void setSubService(String subService) {
        this.subService = subService;
    }
}
