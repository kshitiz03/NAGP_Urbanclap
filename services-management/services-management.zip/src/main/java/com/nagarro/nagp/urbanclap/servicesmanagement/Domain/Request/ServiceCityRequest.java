package com.nagarro.nagp.urbanclap.servicesmanagement.Domain.Request;

public class ServiceCityRequest {

    private String service;

    private String city;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
