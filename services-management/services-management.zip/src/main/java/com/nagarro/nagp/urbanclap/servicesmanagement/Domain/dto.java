package com.nagarro.nagp.urbanclap.servicesmanagement.Domain;

public class dto {
}
