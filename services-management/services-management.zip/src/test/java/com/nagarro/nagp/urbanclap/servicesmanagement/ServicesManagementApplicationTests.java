package com.nagarro.nagp.urbanclap.servicesmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicesManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
