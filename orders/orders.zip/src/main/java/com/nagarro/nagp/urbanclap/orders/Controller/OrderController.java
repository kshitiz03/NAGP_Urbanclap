package com.nagarro.nagp.urbanclap.orders.Controller;

import com.nagarro.nagp.urbanclap.orders.Domain.Request.PlaceOrderRequest;
import com.nagarro.nagp.urbanclap.orders.Domain.Response.BaseResponse;
import com.nagarro.nagp.urbanclap.orders.Domain.Response.ServiceOrderHistory;
import com.nagarro.nagp.urbanclap.orders.Domain.ServicesOrder;
import com.nagarro.nagp.urbanclap.orders.services.OrderService;
import org.bouncycastle.jcajce.provider.symmetric.HC256;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/orders")
public class OrderController {

    public static final Logger logger = LoggerFactory.getLogger(OrderController.class);
    @Autowired
    OrderService orderService;

    @PostMapping(path = "/place-order")
    public ResponseEntity<BaseResponse> getOrderPlaced(@RequestBody PlaceOrderRequest placeOrderRequest) {
    BaseResponse baseResponse = orderService.placeOrder(placeOrderRequest);

    return ResponseEntity.ok(baseResponse);
    }

    @PostMapping(path = "/add-cart/{mobileNo}")
    public ResponseEntity<BaseResponse> saveToCart(@PathVariable String mobileNo, @RequestBody ServicesOrder servicesOrder) {
        BaseResponse baseResponse = orderService.addToCart(mobileNo,servicesOrder);
        return ResponseEntity.ok(baseResponse);

    }

    @PostMapping(path = "/remove-cart/{mobileNo}")
    public ResponseEntity<BaseResponse> removeFromCart(@PathVariable String mobileNo, @RequestBody ServicesOrder servicesOrder) {

        BaseResponse baseResponse = orderService.removeFromCart(mobileNo,servicesOrder);
        return ResponseEntity.ok(baseResponse);

    }

    @PostMapping(path = "/order-summary/{mobile-no}")
    public ResponseEntity<List<ServiceOrderHistory>> getOrderPlaced(@PathVariable String mobileNo) {

        List<ServiceOrderHistory> baseResponse = orderService.getLatestPlacedOrder(mobileNo);
        return ResponseEntity.ok(baseResponse);

    }

    @GetMapping(path = "/order-history/{mobile-no}")
    public ResponseEntity<List<PlaceOrderRequest>> getOrderHistory(@PathVariable String mobileNo) {

        List<PlaceOrderRequest> baseResponse = orderService.getOrderHistory(mobileNo);
        return ResponseEntity.ok(baseResponse);

    }

}
