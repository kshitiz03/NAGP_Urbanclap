package com.nagarro.nagp.urbanclap.Usermanagement.Constants;

public class UMSConstants {


    public static final int PSWD_LENGTH = 16;
}
